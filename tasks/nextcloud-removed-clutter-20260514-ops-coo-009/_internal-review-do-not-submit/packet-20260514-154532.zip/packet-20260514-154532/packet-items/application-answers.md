# Application Questions - Working Answers

Status: draft for applicant approval.

These answers should stay consistent with the challenge packet, cover letter, and proof artifacts.

## 1. Have you worked at a digital marketing agency before?

Short answer:

> Yes. I founded Heaviside in 2011 and have operated it since then across SEO, web design, digital marketing, and related services, including the Paving Marketers and Garage Door Marketers vertical niches.

Expanded answer:

> Yes. I founded Heaviside in 2011 and have operated it since then. The agency started with SEO, web design, and digital marketing, then expanded into related services including cold email, direct mail, social media, and verticalized offers through Paving Marketers and Garage Door Marketers. I am still the founder/operator, but the agency no longer depends on daily founder involvement. My existing businesses take less than `5` hours/week to manage because I have hired competent operators, given them ownership, and built more of the work into systems.

## 2. Can you walk me through how you currently use AI in your day-to-day work?

Short answer:

> I use AI as an operating layer, not just a writing assistant: source gathering, analysis, coding, workflow automation, Slack/client-performance summaries, research, content drafting, scoring gates, and agent/crons that produce work only when there is a route to owner action or outcome logging.

Expanded answer:

> My daily AI use is very practical. I use Codex/Claude Code-style tools for development, debugging, repo analysis, and CLI-driven workflow work. I use SloaneVault as a durable memory layer so decisions, sources, project state, and lessons do not disappear between sessions. I use HeavisideOS in its current practical form for SlackBot summaries and query flows around recent client communication and paid ads/SEO/business-performance context. I use x-accel-style scoring gates to decide whether content or agent output is ready to move forward. I also operate Hermes/open-agents, an agent and scheduled-job layer that handles research, content drafting, infrastructure checks, project status, inbox/briefing flows, fleet monitoring, and cold-email operations. The important rule is that AI output does not count until it becomes accepted work, an explicit rejection, owner action, a system-of-record update, or a rule/memory update.

## 3. Can you give an example of a process or system you built that permanently improved execution?

Short answer:

> HG SEO Commander is the cleanest delivery example. It moved recurring SEO work from manual data retrieval, reporting, content/GBP prep, and queue recovery into a software workflow with source data, scheduled syncs, queues, CLI/admin tools, operator review, and customer-ready deliverables.

Expanded answer:

> One example is HG SEO Commander. Before it, recurring SEO delivery depended on operators manually pulling data from multiple sources, assembling reports, checking rankings/local visibility, and producing deliverables like GBP posts and blog posts. The system now integrates GA4, Search Console, Google Business Profile, SERP/geogrid tracking, citations, AI articles, GBP posts, bulk posting approvals, scheduled syncs, queues, and CLI/admin operations. It conservatively removes `3-4` hours per active SEO client per month from routine data pulls, status checks, report assembly, GBP/content prep, and queue recovery. Strategy and quality review stay human, but the repetitive execution layer moved into software. The adoption lesson was important: people use tools that remove bad work. When a bad GBP-post bug created manual cleanup, I fixed it through the CLI and showed the operator how to use the tooling instead. They were excited because the new process made them more capable.

Alternate sales-side example:

> HG Market Report automated the front-end sales audit. Instead of manually collecting business/GBP context, pulling local search data, taking screenshots, building a slide deck, and sending a custom report, the system captures prospect context, generates keywords and service area, queues SEO audit / SERP / geogrid reports, derives lost-revenue / quick-win / competitor views, creates a public presentation URL, and sends the report-ready email. It saves an estimated `1-2` hours per standard sales audit and gives prospects a useful path even when they do not want to engage sales immediately.

## Application Consistency Notes

- The "MMPI-style" item is the challenge's self-assessment request, not a clinical MMPI. Our packet uses LLM-guided self-assessment plus Kolbe / Enneagram / MBTI-style operating-profile work and compares the practical wiring to Eric's profile in the brief.
- Do not overclaim HeavisideOS. Current real use is SlackBot summaries/query flows around client communication and paid ads/SEO/business-performance context, plus the broader company-brain direction.
- Do not claim x-accel is part of HeavisideOS. It is separate.
- Do not present Hermes cold email as a clean current-performance proof unless live credentials/launch state are verified. Use it as built-system / closed-loop operating evidence.
- Keep the existing-businesses point framed as delegated operating capacity, not casual divided attention.

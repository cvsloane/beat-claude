# GM Job Post Line-By-Line Scorecard

Status: working review document for application QA.

Source: Single Grain General Manager (Agency) job post, rechecked 2026-05-14: `https://careers.singlegrain.com/jobs/567472-general-manager-agency`.

Purpose: score the application packet against the exact "not a fit" and "strong candidates" lines, not just the general role vibe.

## Exclusion Criteria

These are the lines where the job post says the role is not a fit if experience is primarily the listed pattern.

| Job-post exclusion line | Current strength against exclusion | Score | Evidence in packet | Gap / next proof |
|---|---:|---:|---|---|
| Managing teams without improving systems | Very strong against exclusion | `9.5/10` | HG Market Report, HG SEO Commander, HeavisideOS Slack eval, Hermes/open-agents, RPE/margin history. | Add one concise talent-management example if space exists, but do not bloat. |
| Coordinating projects rather than building infrastructure | Very strong against exclusion | `9.5/10` | FDE framing, source-data -> generated deliverable -> operator review -> customer send/publish -> outcome log, operating artifact, Hermes proof. | Keep infrastructure examples concrete and avoid internal-tool sprawl. |
| Relying on founder involvement to resolve operational issues | Strong against exclusion | `9/10` | Existing businesses take less than `5` hours/week to manage; public org chart and ownership map; PASCO/full-time role while agency sustained/grown. | Stronger with calendar/time log or operator reference. |
| Growing headcount without improving efficiency | Very strong against exclusion | `9/10` | 2023 -> 2026 RPE and margin history; sensible simplification after overstaffing; not artificial shrinkage. | Explain hiring discipline if asked; raw finance should remain redacted. |

Overall exclusion-risk read: low if framed as operational leverage and delegated capacity. Main watchout is the existing-businesses point; it must read as proof that the businesses are delegated/system-run, not that Chris intends to split attention casually.

## Strong-Candidate Lines

| Job-post strong-candidate line | Current fit | Score | Evidence in packet | Gap / next proof |
|---|---:|---:|---|---|
| Operated or scaled a performance marketing agency or service business | Strong | `8.5/10` | Founder/operator of Heaviside since 2011; SEO, web design, digital marketing, related services; PVM/GDM vertical niches; sales/delivery systems. | Smaller than Single Grain; clarify founder/operator scale honestly. |
| Built operational systems that significantly improved productivity | Very strong | `9.25/10` | HG Market Report saves estimated `1-2` hours/report; HG SEO Commander saves estimated `3-4` hours/client/month; HeavisideOS eval improvement; Hermes fleet. | Time-savings estimates should remain labeled unless backed by time logs. |
| Demonstrated strong financial discipline | Strong | `8.75/10` | P&L-based RPE/net margin history; improved productivity and margin together; avoids artificial shrinkage. | Could add one hiring/cost-governance story if needed. |
| Built leadership teams capable of operating independently | Strong | `8.75/10` | Less than `5` hours/week founder management; PASCO/full-time role; public roster; ownership map; org chart proof. | Third-party/operator references would lift this. |
| Used AI or automation to increase operational leverage | Very strong | `9.5/10` | HG Market Report, HG SEO Commander, HeavisideOS, Hermes/open-agents, x-accel gate, SloaneVault, councils. | Keep proof hierarchy simple to avoid complexity penalty. |

## Candidate Profile Lines

| Job-post profile line | Current fit | Score | Evidence |
|---|---:|---:|---|
| Former agency GMs or COOs | Partial by title, strong by function | `7.75/10` | Founder/operator has done GM/COO work inside own agency, but not titled as outside agency GM. |
| Operators from performance marketing agencies | Strong | `8.5/10` | Heaviside/PVM/GDM delivery, paid media/SEO/web ops, sales team and agency systems. |
| Founders who scaled service businesses | Very strong | `9/10` | Heaviside since 2011, vertical niches, agency runs with limited founder management. |
| Operational discipline | Strong | `8.75/10` | GTD/Todoist, SloaneVault, command queue, gates, scorecards, cadence, memory. |
| Strong hiring judgment | Strong but mostly applicant-stated | `8.5/10` | Agency operating bench, under `5` hours/week founder management, PASCO parallel role. |
| Financial rigor | Strong | `8.75/10` | P&L/RPE/margin model, not artificial shrinkage, revenue/FTE focus. |
| Systems thinking | Very strong | `9.5/10` | Entire packet is built around systems, source records, writeback, dashboards, and memory. |
| AI-forward mindset | Very strong | `9.5/10` | AI workflows, agent fleet, AI usage disclosure, human boundaries, model/tool-spend awareness. |

## Core Responsibility Fit

| Responsibility | Fit score | Read |
|---|---:|---|
| Operational leadership | `8.75/10` | Strong plan and artifact; needs live SG economics/team access to calibrate. |
| Financial discipline | `8.75/10` | Strong RPE/margin proof; can improve with hiring-decision story. |
| Talent leadership | `8.75/10` | Stronger after adding less-than-`5`-hours/week proof; still mostly self-reported. |
| Founder leverage | `9.5/10` | One of the strongest matches. The plan explicitly reduces Eric's review load. |
| Systems and AI infrastructure | `9.5/10` | Very strong and central to the packet. |

## Current Verdict

The application is aligned with the job post's real screen. It does not read like a traditional agency operator, project coordinator, founder-dependent operator, or headcount-growth operator. It reads like a founder/operator who builds leverage systems, has measurable RPE/margin proof, and understands the CEO-leverage problem.

Next improvement should be selective: one concrete talent/accountability story or one operator reference would improve the only remaining weaker area. Do not add more tool names unless they support the "outputs -> outcomes" thesis.

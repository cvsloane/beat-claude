# Ops COO 009 - Operating Artifact v2

Purpose: turn Single Grain's agent output into measurable leverage: accepted work, owner action, memory updates, lower CEO review load, and a path toward higher revenue per employee.

Number-source rule: challenge facts are labeled `[Observed from brief]`; proposed thresholds, cadence, and operating design are labeled `[Assumed]` until calibrated against Single Grain's live queue, CRM, analytics, finance, and team capacity.

Public-site calibration: Single Grain publicly sells AI-native execution inside the customer's operating stack, not disconnected AI dashboards. The implementation should assume source systems like Slack, HubSpot/Salesforce, Gong, GA4, GSC, CMS, LinkedIn, ClickFlow, Karrot, and Single Brain. The operating standard should match the public Single Brain promise: one trusted interface, a commander/fleet behind it, clear status, client/data isolation, and Security/Stability/Reliability `[Observed from public websites]`.

## 1. Revenue/FTE Operating Loop

```text
source data
  -> agent output
  -> source check
  -> value score + risk flags
  -> green / yellow / red route
  -> owner execution
  -> system-of-record writeback
  -> accepted-work log
  -> outcome + cost record
  -> memory/rule update
  -> revenue/FTE review
```

Core rule: an AI output does not count until it becomes an accepted action, explicit rejection, owner assignment, or rule/memory update.

Single Grain language version: strategy audit and quick wins -> growth roadmap -> rapid execution -> scale what works `[Observed from public websites]`.

Primary operating goal: reduce Eric from `60+` minutes/day of approvals `[Observed from brief]` to `15` minutes/day `[Observed from brief]` and `3-5` real decisions/day `[Observed from brief]`, while tying AI workflows to retention, pipeline, margin, productivity, and revenue/FTE.

## 2. CEO Operating Contract

The brief gives the operating clue: Eric is ENTJ / `8w7`, Kolbe Quick Start `9`, Follow Thru `2`, self-rated low on follow-through, organization, and workflow consistency, and "starts `10` things, finishes `3`" `[Observed from brief]`. Do not make the system depend on his follow-through.

| Eric should do | GM / system should do |
|---|---|
| Set strategic direction, taste, standards, partnerships, and red-line decisions. | Convert starts into owned work, status, dates, decision logs, and outcomes. |
| Use his Quick Start energy to create options and find leverage. | Keep a `10 starts -> 10 closed loops` ledger `[Assumed]`: shipped, killed, delegated, parked, or escalated. |
| Spend `15` minutes/day `[Observed from brief]` on true red decisions. | Protect him from yellow/green review debt and summarize only exceptions. |
| Jump to the next big idea without carrying the process in his head. | Maintain memory, owners, writebacks, and follow-through outside the CEO's attention. |

Applicant fit: Chris's profile is INTP / `6w5` with strong Type `1`, Kolbe `9-4-3-2` `[Observed self-assessment]`. Practical use: source-checking, preparedness, standards, and error-correction as the counterweight to high-Quick-Start CEO energy.

## 3. First 48-Hour Command Queue

| Status | Meaning | SLA |
|---|---|---|
| `dead` | Duplicate, stale, irrelevant, or no longer recoverable. | Same-day close `[Assumed]` |
| `needs_source_check` | Potentially useful, but data/source is unverified. | `4` business hours `[Assumed]` |
| `green_auto` | Low-risk, reversible, source-verified, known pattern. | Same day `[Assumed]` |
| `yellow_owner` | Needs GM/domain-owner review, not Eric. | `4` business hours `[Assumed]` |
| `yellow_council` | High-value ambiguity needing expert judgment. | `24` hours `[Assumed]` |
| `red_eric` | Strategic, irreversible, public, pricing, legal, people, or key-relationship risk. | Eric's `30`-minute block `[Observed from brief]` |
| `executed` | Action taken and owner assigned. | Log within `24` hours `[Assumed]` |
| `learning_logged` | Outcome changed a rule, prompt, threshold, or SOP. | Weekly sweep `[Assumed]` |

## 3A. First 48-Hour Takeover Timeline

The written answer compresses this for page fit. The operating version is more literal:

| Window | Action | Outcome |
|---|---|---|
| Hour `0-1` `[Assumed]` | Snapshot Mission Control, review queue, ClickFlow churn flags, expired outreach, CRM, product usage, Slack, GSC/GA4, and source links. | One source-backed command queue. |
| Hour `1-2` `[Assumed]` | Classify all `23` pending items `[Observed from brief]` into `dead`, `needs_source_check`, `green_auto`, `yellow_owner`, `yellow_council`, or `red_eric`. | No unknown/unclassified backlog. |
| Hour `2-3` `[Assumed]` | Pull ClickFlow churn context for the `2` lost customers `[Observed from brief]`: usage, support, contract value, last owner action, save path. | Churn recovery packets ready. |
| Hour `3-5` `[Assumed]` | Assign churn recovery owner and decide whether any item requires Eric because of pricing, strategic relationship, or customer-trust risk. | Churn routed before backlog cleanup. |
| Hour `5-6` `[Assumed]` | Review `3` stale prospects `[Observed from brief]`: CRM stage, last reply, account fit, trigger, relationship risk, owner. | Re-entry or dead-item decision per prospect. |
| Hour `6-8` `[Assumed]` | Clear routine greens, mark dead items, and move source-uncertain items to source check. | Queue size collapses without using Eric as reviewer. |
| Hour `8-10` `[Assumed]` | Prepare Eric's `3-5` red decisions `[Observed from brief]` plus red-line/delegation asks. | Eric gets decision packet, not discovery. |
| Hour `10-24` `[Assumed]` | Execute green/yellow owner actions, write back decisions, and schedule day-two Oracle/Shaun work. | Day one ends with no unowned yellow/red item. |
| Day `2`, morning `[Assumed]` | Meet Eric for `30` minutes `[Observed from brief]`; meet Shaun to identify agent failure modes and dashboard/writeback gaps. | Delegation boundary plus tech constraint map. |
| Day `2`, afternoon `[Assumed]` | Source-check Oracle's `15` inherited quick-win keywords `[Observed from brief]`; route winners into owner actions and losers into memory. | SEO outputs become accepted work or explicit rejections. |
| Day `2`, close `[Assumed]` | Publish accepted-work, rejected-work, red-decision, owner, and rule-update summary. | The system has started converting output into outcomes. |

## 4. Day-One Fire Order

| Fire / item group | Initial route | Why | First action | Eric needed? |
|---|---|---|---|---|
| `2` ClickFlow churn customers `[Observed from brief]` | `yellow_owner` -> possible `red_eric` | Active TES/SaaS revenue loss outranks backlog cleanup. | Pull product usage, GSC/GA4 where relevant, support history, contract value, churn signal, save path, and owner. | Only for pricing, strategic relationship, or customer-trust judgment. |
| `3` stale sales prospects `[Observed from brief]` | `yellow_owner` | Pipeline decay has time value but usually does not need CEO review. | Check CRM/HubSpot/Salesforce stage, last reply, Gong/call context if available, account fit, relationship risk, owner, and trigger. Re-entry note or mark dead. | Only named account / Eric relationship. |
| `23` pending review items `[Observed from brief]` | Batch through score gate. | Age is a symptom; contents decide priority. | Sort into queue statuses and pull only `3-5` red items `[Observed from brief]` for Eric. | Red items only. |
| `15` Oracle quick-win keywords `[Observed from brief]` | `needs_source_check` -> `green_auto` or `yellow_owner` | SEO upside exists only if source, intent, existing page, and owner check out. | Verify GSC/GA4 data, existing-page fit, intent, effort, CMS/ClickFlow state, and convert winners into roadmap items. | Only strategic page / brand risk. |

## 5. Eric's 30-Minute Calibration Block

| Minute | Ask | Output |
|---:|---|---|
| `0-5` `[Assumed]` | "I am handling churn, stale prospects, and queue routing first. Any reversal?" | Priority confirmation. |
| `5-12` `[Assumed]` | "Which actions are never auto-approved?" | Red-line list. |
| `12-18` `[Assumed]` | "What can I decide without you for `7` days `[Assumed]`?" | Temporary delegation boundary. |
| `18-24` `[Assumed]` | Review only `3-5` `red_eric` items `[Observed from brief]`. | Decisions / deferrals. |
| `24-30` `[Assumed]` | "Which metric should be on tomorrow morning's briefing?" | CEO leverage metric. |

## 6. Score-To-Route Gate

Separate value from risk. A blended score should never hide an irreversible or reputation-sensitive item.

### Action Value Score

Each field is scored `0/1/2` `[Assumed]`; max value score is `14` `[Assumed]`.

| Field | 0 | 1 | 2 |
|---|---|---|---|
| Revenue proximity | No revenue tie | Indirect revenue / productivity | Active revenue, pipeline, churn, retention |
| Time sensitivity | Can wait a week | Needs this week | Degrades within `24-48` hours `[Assumed]` |
| Source confidence | Vague / unverified | Partial source | Source record available |
| System writeback | No writeback path | Manual update required | CRM/CMS/queue writeback available |
| Owner clarity | No owner | Owner category known | Named owner can act today |
| Effort size | `>1` day `[Assumed]` | Half-day `[Assumed]` | `<1` hour `[Assumed]` |
| Learning value | One-off | Some pattern value | Improves future routing/prompt/rule |

### Risk Flags

| Flag | Route pressure | Examples |
|---|---|---|
| Irreversible customer-facing commitment | Red | Pricing, refund, contract, public promise |
| Strategic relationship / named account | Red | CEO relationship, enterprise logo, partner |
| Brand/public reputation risk | Red | Strong POV, public figures, competitors |
| Legal/privacy/security risk | Red | PII, data access, compliance |
| High financial exposure | Red | Spend changes, custom deal structure |
| Novel action with no precedent | Yellow | First live execution of a workflow |
| Low source confidence | Yellow | Agent lacks source record |
| Reversible routine action | Green possible | Internal brief, approved-template draft, owner reminder |

### Routing Rules

| Route | Criteria | Examples | Logging |
|---|---|---|---|
| Green | Value `>=7` `[Assumed]`, no red flags, source verified, reversible, known pattern. | Internal brief, approved-template content, routine SEO title/internal-link task. | Auto-execute; daily summary. |
| Yellow owner | Value `>=5` `[Assumed]` or uncertainty without CEO-specific risk. | Churn investigation, new-page SEO recommendation, non-ICP prospect, sales re-entry note. | Owner review within `4` hours `[Assumed]`; outcome logged. |
| Yellow council | High-value ambiguity where expert judgment improves the call. | Creative refresh, channel pivot, SEO/content positioning, paid media restructure. | Council memo; GM decision. |
| Red Eric | Any red flag or CEO-specific context. | Pricing, strategic account, public controversy, irreversible customer promise, senior people issue. | `3-5` item Eric queue `[Observed from brief]`. |
| Kill/defer | Value `<5` `[Assumed]` and no time-sensitive downside. | Daily competitor pricing noise, low-signal candidate follow-up. | Rejection reason logged. |

## 7. Agent-Specific Examples

| Agent | Green | Yellow | Red |
|---|---|---|---|
| Oracle | Existing-page metadata/internal-link quick win with verified GSC/GA4 data and CMS/ClickFlow path. | New page, mixed intent, material rewrite. | Public SEO/AEO claim, strategic positioning page, customer-sensitive case study. |
| Flash | Repurpose approved video into template-matched post. | New hook pattern, strong POV, competitor mention. | Public figure, partner, legal/brand-sensitive claim. |
| Cyborg | Follow-up inside approved sequence for non-strategic prospect with CRM writeback. | New ICP edge case, high-fit senior buyer, unusual personalization. | Eric relationship, named account, offer/pricing change. |
| Alfred | Internal briefing, owner reminder, cross-agent status summary. | Churn investigation, deal revival, workflow proposal. | New core cron, killing core cron, pricing/client escalation. |

## 8. Cron Audit Framework

Audit question: does this cron create accepted work or review debt?

Score each cron by action rate, revenue proximity, review burden, source quality, owner clarity, false-positive cost, false-negative cost, and memory feedback `[Assumed]`.

| Cron | Current signal | Verdict | Reason | 30-day change |
|---|---:|---|---|---|
| GSC Quick Win Scan | `12%` actioned `[Observed from brief]` | Improve | Potentially valuable, but current volume creates noise. | Surface only verified existing-page, commercial-intent opportunities with clear owner and low effort. |
| LinkedIn Prospect Sourcer | `8%` meetings `[Observed from brief]` | Improve | Pipeline-relevant, but `2x/day` `[Observed from brief]` likely floods review. | Tighten ICP/trigger/relationship score; batch daily `[Assumed]`; require CRM/HubSpot writeback and pipeline-impact read. |
| Content Repurpose - YouTube | `35%` published `[Observed from brief]` | Keep / improve | Editorial rejection is healthy; needs winner/loser memory. | Feed accepted/rejected hooks into memory weekly `[Assumed]`. |
| Deal Revival Scan | `60%` followed up `[Observed from brief]` | Keep | Revenue-proximate, low-volume, clear owner action. | Require follow-up outcome logging. |
| Competitor Pricing Monitor | `3%` action `[Observed from brief]` | Kill / pause | Daily pricing scrape creates rare action and executive distraction. | Replace with monthly or exception-based scan `[Assumed]`. |
| Churn Signal Detector | `20%` investigated `[Observed from brief]` | Improve urgently | False negatives are expensive; response loop is broken. | Same-day yellow escalation with owner, source links, customer state, and save-play status `[Assumed]`. |
| Weekly Content Calendar | `50%` used `[Observed from brief]` | Keep / improve | Useful planning artifact if tied to accepted work. | Track publish/outcome and feed winners back into memory. |
| Candidate Outreach Follow-up | `5%` response `[Observed from brief]` | Kill / redesign | Low response plus brand risk from robotic follow-up. | Kill auto-follow-up; weekly top-`5` human review only `[Assumed]`. |

## 9. Revenue/FTE Dashboard

This is the monthly GM view that keeps AI leverage tied to business health, not output volume.

| Metric | Source | Why it matters |
|---|---|---|
| Revenue per FTE | Finance + people data | Primary GM mandate from job post. |
| TES revenue mix | Finance + ClickFlow/Karrot/product data | Tracks progress toward `50%` TES revenue by 2028 `[Observed from brief]`. |
| Net margin | P&L | Prevents artificial shrinkage and hidden service debt. |
| Accepted agent work | Queue log | Separates production from noise. |
| CEO red decisions/day | `red_eric` queue | Measures founder leverage. |
| Churn flags investigated same day | ClickFlow/product + queue | Protects TES revenue. |
| Pipeline re-entry actions completed | CRM + queue | Recovers stale demand. |
| Cost per accepted action | model/tool spend + queue | Prevents hidden AI/tool bloat. |
| Writeback completion rate | CRM/CMS/queue audit | Prevents useful Slack messages from dying outside the system of record. |

## 10. Mistake Handling

When a green item should not have auto-executed:

1. Reverse if reversible.
2. Notify the owner in `3` lines `[Assumed]`: what happened, current risk, correction.
3. Move the item type from green to yellow.
4. Add a memory record with failed rule, source, route, impact, and new threshold.
5. Review weekly `[Assumed]`; `2` repeated failures `[Assumed]` in one category means the rule is wrong.

## 11. Memory Record Schema

```yaml
item_id:
agent:
source_links:
system_of_record:
input_summary:
route: green_auto | yellow_owner | yellow_council | red_eric | killed
route_reason:
owner:
action_taken:
writeback_status:
audit_link:
outcome_metric:
cost_or_time_spend:
failure_or_exception:
rule_update:
next_review_date:
```

## 12. Operating Cadence

| Cadence | Artifact / meeting | Purpose |
|---|---|---|
| Daily `7:30 AM` `[Assumed]` | CEO leverage briefing | `3-5` red decisions `[Observed from brief]`, churn/pipeline exceptions, yesterday's accepted work. |
| Daily `4:30 PM` `[Assumed]` | Queue closeout | Zero unowned yellow/red items; all executions logged. |
| Weekly `[Assumed]` | Cron audit / rule tuning | Kill, pause, tighten, or graduate crons based on outcomes. |
| Weekly `[Assumed]` | Memory sweep | Convert repeated decisions into rules, prompts, SOPs, or kill criteria. |
| Monthly `[Assumed]` | Revenue/FTE review | Tie AI leverage to revenue, retention, margin, and productivity. |
| Monthly `[Assumed]` | Model/tool spend review | Check model hierarchy, API fallback use, and cost per accepted action. |

## 13. SSR Trust Check

Borrow the public Single Brain operating standard `[Observed from public websites]` and make it operational:

| Standard | GM test |
|---|---|
| Security | Correct data scopes, no client data bleed, credential hygiene, role-based access. |
| Stability | Agents do not drift, repeat bad actions, or require constant rescue. |
| Reliability | Owners see clear status, completed work, audit trail, and response times fast enough to trust. |

## 14. What Stays Human

- Pricing, discounts, refunds, contract terms, and spend-risk decisions.
- Strategic account communication and client retention conversations where trust is at risk.
- Public claims involving customers, partners, competitors, public figures, or legal/regulatory issues.
- Hiring/firing, senior candidate persuasion, and people conflict.
- Automation rules that have not survived live review.
- Eric-specific taste, vision, partnerships, and strategic priority tradeoffs.

## 15. What Breaks It

- Source data is wrong, stale, missing, or inaccessible.
- CRM stages, GSC/GA4 access, enrichment, CMS state, or account ownership are dirty before the agent acts.
- Agents post useful Slack messages but do not write outcomes back to CRM/CMS/queue.
- Agents optimize output volume instead of accepted work.
- Yellow items have no owner or SLA.
- Eric keeps reviewing non-red decisions.
- Councils become delay theater instead of high-value judgment.
- Memory records are not updated, so mistakes repeat.
- Churn/pipeline items are treated like ordinary queue items.
- Client/data isolation or permission scope is unclear.
- Model/tool spend is unmanaged, with no hierarchy or cost per accepted action.
- The dashboard becomes the work instead of a trigger for execution.

## 16. Evidence Hooks

| Claim in packet | Proof source |
|---|---|
| I have moved revenue/FTE and margin together. | QuickBooks P&L snapshots and FTE model summarized in evidence log. |
| I use gated scoring / routing patterns. | x-accel gate/scoring source records and sanitized workflow summary. |
| I use expert councils for ambiguity. | Decision Council workflow and safe/anonymized council artifact. |
| I maintain durable operating memory. | SloaneVault/qmd index, lessons, project notes, and decision logs. |
| I have built sales and delivery automation. | HG Market Report and HG SEO Commander summaries. |
| I have operated a real scheduled-agent / cron fleet. | Hermes/open-agents scheduler manifests and live state summarized in the evidence log. |
| I understand maturity limits. | Explicit distinction among x-accel, SloaneVault, and early-stage HeavisideOS. |
